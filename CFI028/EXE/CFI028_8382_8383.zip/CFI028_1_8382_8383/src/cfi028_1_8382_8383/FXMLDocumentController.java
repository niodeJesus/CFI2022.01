/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cfi028_1_8382_8383;

import static java.lang.Math.pow;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;

/*
IMC	        Classificação
 < 16	        Magreza grave
 16 a < 17	Magreza moderada
 17 a < 18,5	Magreza leve
 18,5 a < 25	Saudável
 25 a < 30	Sobrepeso
 30 a < 35	Obesidade Grau I
 35 a < 40	Obesidade Grau II (severa)
 ≥ 40           Obesidade Grau III (mórbida)
 */
public class FXMLDocumentController implements Initializable {
    
    private Label label;
    @FXML
    private Label lblImc;
    @FXML
    private TextField txtPeso;
    @FXML
    private TextField txtAltura;
    @FXML
    private Button btnCalcularClick;
    @FXML
    private Button btnLimparClick;
    @FXML
    private Label lblPeso;
    @FXML
    private Label lblAltura;
    

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void btnCalcularClick(ActionEvent event) {
        
        float altura = Float.valueOf(txtAltura.getText());
        float peso = Float.valueOf(txtPeso.getText());
        
        float imc;
        imc = (float) (peso / pow(altura, 2));
        
        lblImc.setText(String.valueOf(imc));
        
        Image iicon = new Image ("iicon.png");
        
        if (imc < 16){
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(null);
        alert.setHeaderText(null);
        alert.setContentText("Magreza grave");
        alert.showAndWait();
        alert.setX(450);
        alert.setY(200);
        
        }
        else if(imc < 17) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(null);
        alert.setHeaderText(null);
        alert.setContentText("Magreza moderada");
        alert.showAndWait();
        alert.setX(450);
        alert.setY(200);        
        }
        else if (imc < 18.5) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(null);
        alert.setHeaderText(null);
        alert.setContentText("Magreza leve");
        alert.showAndWait();
        alert.setX(450);
        alert.setY(200);       
        }
        else if (imc < 25) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(null);
        alert.setHeaderText(null);
        alert.setContentText("Saudável");
        alert.showAndWait();
        alert.setX(450);
        alert.setY(200);        
        }
        else if (imc < 30) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(null);
        alert.setHeaderText(null);
        alert.setContentText("Sobrepeso");
        alert.showAndWait();
        alert.setX(450);
        alert.setY(200);        
        }
        else if (imc < 35) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(null);
        alert.setHeaderText(null);
        alert.setContentText("Obesidade Grau I");
        alert.showAndWait();
        alert.setX(450);
        alert.setY(200);        
        }
        else if (imc < 40) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(null);
        alert.setHeaderText(null);
        alert.setContentText("Obesidade Grau II (severa)");
        alert.showAndWait();
        alert.setX(450);
        alert.setY(200);        
        }
        else{
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(null);
        alert.setHeaderText(null);
        alert.setContentText("Obesidade Grau III (mórbida)");
        alert.showAndWait();
        alert.setX(450);
        alert.setY(200);
       
        }
        }
    

        
        
        
        
    

    @FXML
    private void btnLimparClick(ActionEvent event) {
//Código do Toninho
// CRIANDO UM VETOR DE NODES, onde nodes s~qo qualquer componente visual
// ue pode ser utilizado em uma tela javaFX (label, button, combobox, etc)
    Node[] listaObjetos = {lblImc, txtAltura, txtPeso};
    for (Node n : listaObjetos) {

      if (n instanceof Label) {
        ((Label) n).setText("");
      } else if (n instanceof TextField) {
        ((TextField) n).setText("");
      }
    }
        
    }
    
}
