/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cfi028_1_8382_8383;

import static java.lang.Thread.sleep;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

/**
 *
 * @author aluno
 */
public class CFI028_1_8382_8383 extends Application {
    
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        
        Scene scene = new Scene(root);
        Image icon = new Image ("icon.png");
        Image iicon = new Image ("iicon.png");
        stage.setTitle("Calculadora de IMC");
        stage.setResizable(false);
        

         stage.getIcons().add(icon);



        stage.setScene(scene);
        stage.setX(228);
        stage.setY(50);
        stage.show();
        
        stage.getIcons().add(icon);
        sleep(4000);
        stage.getIcons().add(iicon);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
